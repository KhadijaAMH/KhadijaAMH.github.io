# Bali Tourism Template
Indonesia Bali tourism template example

![yogs_tourism](https://user-images.githubusercontent.com/25165999/56662279-d470c580-66cd-11e9-8154-55c05fb9e568.png)

Demo : https://tourism-bali.netlify.app/

## Technology
*  Bootstrap
*  Jquery

I was very happy if you leave a star in this project :)
